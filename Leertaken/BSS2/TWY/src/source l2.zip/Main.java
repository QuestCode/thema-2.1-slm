/**
 * Created by Yuri on 8/5/2014.
 */
public class Main {
    public static void main(String[] args){
        new Receiver(7789, 10, 850);
    }
}
