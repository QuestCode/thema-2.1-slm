/**
 * Handler class containing the logic for sending results back
 * to the client. 
 * 
 * This implementation reads an IP name from the socket, looks up
 * the IP address, and sends it back 
 *
 * @author Gagne, Galvin, Silberschatz
 * Operating System Concepts with Java - Eighth Edition
 * Copyright John Wiley & Sons - 2010.
 */
 
import java.io.*;
import java.net.*;

public class Handler 
{
	/**
	 * this method is invoked by a separate thread
	 */
	public void process(Socket client) throws java.io.IOException {
		BufferedReader fromClient = null;
		DataOutputStream toClient = null;
		
		try {
			/**
			 * get the input and output streams associated with the socket.
			 */
			fromClient = new BufferedReader(
				new InputStreamReader(client.getInputStream()));
			toClient = new DataOutputStream(client.getOutputStream());
		
			/** first read the IP name being requested */
			String IPName = fromClient.readLine();	

			/** now look up the IP address corresponding to the name */
			String hostAddress;
			
			try {
				InetAddress hostInetAddress = InetAddress.getByName(IPName);
				hostAddress = hostInetAddress.getHostAddress();
			}
			catch (UnknownHostException uhe) {
				hostAddress = "Unknown Host";
			}	

			// write the result to the socket
			toClient.writeBytes(hostAddress.toString()+"\r\n");
       	}
		catch (IOException ioe) {
			System.err.println(ioe);
		}
          finally {
          	// close streams and socket
          	if (fromClient != null)
          		fromClient.close();
          	if (toClient != null)
          		toClient.close();
		}
	}
}
