/**
 * Naming server client.
 *
 * Usage
 *	java NSClient [server] [IP name]
 *
 * @author Gagne, Galvin, Silberschatz
 * Operating System Concepts with Java - Eighth Edition
 * Copyright John Wiley & Sons - 2010.
 */

import java.net.*;
import java.io.*;

public class NSClient
{
	// the default port
	public static final int PORT = 6052;

	public static void main(String[] args) throws java.io.IOException {
		BufferedReader fromServer = null;
		DataOutputStream toServer = null;
		Socket server = null;

		if (args.length != 2) {
			System.err.println("Usage: java Client [server] [host name]");
			System.exit(0);
		}

		try {
			// create socket and connect to default port 
			server = new Socket(args[0], PORT);

			// get the input and output streams
			fromServer = new BufferedReader(new InputStreamReader(server.getInputStream()));
			toServer = new DataOutputStream(server.getOutputStream());

			// write the host name to the socket
			toServer.writeBytes(args[1].toString() +"\r\n");

			// read the server response and close the socket
			System.out.print(fromServer.readLine());

			// closing the input stream closes the socket as well
			fromServer.close();
		} catch (java.io.IOException ioe) {
			System.err.println(ioe);
		}
		finally {
			// let's close streams and sockets
			if (fromServer!= null)
				fromServer.close();
			if (server != null)
				server.close();
		}
	}
}
