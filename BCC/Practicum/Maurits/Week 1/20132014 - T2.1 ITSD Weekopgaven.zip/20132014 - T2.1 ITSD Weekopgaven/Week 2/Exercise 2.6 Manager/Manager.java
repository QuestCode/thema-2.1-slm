/**
 * Manager.java
 *
 * File for use with exercise 6.39
 *
 * @author Gagne, Galvin, Silberschatz
 * Operating System Concepts with Java - Eighth Edition
 * Copyright John Wiley & Sons - 2010.
 */

public class Manager
{
	public static final int MAX_RESOURCES = 5;
	private int availableResources = MAX_RESOURCES;

	/**
	 * This method is now thread-safe and a waiting thread blocks
	 * until sufficient resources are available.
	 */
	public synchronized void decreaseCount(int count) {
		while (availableResources < count) {
			try {
				wait();
			}
			catch (InterruptedException ie) { }
		}
			
		availableResources -= count;
	}

	/**
	 * Return the resources.
	 */
	public synchronized void increaseCount(int count) {
		availableResources += count;
		
		notify();
	}
}
